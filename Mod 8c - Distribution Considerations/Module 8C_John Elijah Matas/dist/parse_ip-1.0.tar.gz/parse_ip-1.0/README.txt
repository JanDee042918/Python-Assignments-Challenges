This package parses the html and gets only the ip address to be shown.
To use:

import parse_ip

ip_address = parse_ip.show_ip()